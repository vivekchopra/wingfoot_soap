Wingfoot SOAP
----------------

Wingfoot SOAP is an implementation of SOAP 1.1 client for MIDP/CLDC. It also works 
on Personal Java, J2SE and J2EE platforms.

You are welcome to use Wingfoot SOAP 1.0 for evaluation and development purposes. 
For commercial use, please contact Wingfoot Software at info@wingfoot.com.

Features:

- Small and fast. 
- Build-in support for int, integer, long, short, float, boolean, 
  string, dateTime, base64 and beans. 
- Serialization and deserialization are done automatically.
- Custom serializer can be easily pluged in. 
- Supports Hashtable and Vector from Apache SOAP. 
- Not bound to a transport protocol.  Support for HTTP provided.

Release contents:

Wingfoot SOAP 1.0 contains a jar file name wsoap_1.0.jar. When extracted
the jar file produces the following directory structure:

1. A directory named wsoap/demos.  This contains some MIDP samples that use
   Wingfoot SOAP to access services hosted at www.xmethods.com.

2. A directory named wsoap/doc.  This directory contains the following:

   - javadoc.jar. This is the Wingfoot SOAP API as a Javadoc.  This can be
     extracted in any suitable location.

   - WSOAP_User_Guide1_0.pdf.  A small document that provides an overview of 
     Wingfoot SOAP.

   - interopBase.html and interopGroupB.html  Results of the interop test
      conducted on Wingfoot SOAP 1.0.

3. A directory named wsoap/lib.  This has the necessary jarfiles that can be
   used to access Wingfoot SOAP API.

   - j2sewsoap_xml_1_0.jar: This jar file targets the J2SE and J2EE platform. 
     It can be used in CDC/Personal Java platforms.

   - kvmwsoap_xml_1_0.jar: This jar file targets the J2ME (CLDC/MIDP) 
     platform. It is preverified and includes the kXML parser.


