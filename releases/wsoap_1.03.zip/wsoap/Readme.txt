Wingfoot SOAP
----------------

Wingfoot SOAP is an implementation of SOAP 1.1 client for MIDP/CLDC.  It uses kXML,
the open source XML parser from Lutris Technologies.

Wingfoot SOAP works on Personal Java, J2SE and J2EE platforms.

Features:

- Small and fast. 
- Build-in support for int, integer, long, short, float, boolean, 
  string, dateTime, base64 and beans. 
- Serialization and deserialization are done automatically.
- Custom serializer can be easily pluged in. 
- Supports Hashtable and Vector from Apache SOAP. 
- Not bound to a transport protocol.  Support for HTTP provided. Additional
- protocol can be easily plugged in.

Release 1.03 
This release addresses the following:

1. Support for session using cookies. The useSession method in HTTPTransport
   and J2SEHTTPTransport can be used to maintain a session with the server;

2. Preversing the serialization order while deserializing a SOAP payload;

3. Better support for servers sending multi-ref (href) payload;

4. Fixed the reported defect that incorrectly deserialized beans that 
   was nested in a Vector;

5. Proven interoperability with a lot more SOAP server implementations.


Release contents:

Wingfoot SOAP 1.03 contains a zip file named wsoap_1.03.zip. When extracted
the jar file produces the following directory structure:

1. A directory named wsoap/demos.  This contains some MIDP samples that use
   Wingfoot SOAP to access services hosted at www.xmethods.com.  It also 
   includes a Midlet that uses the Goggle Search API.  

2. A directory named wsoap/doc.  This directory contains the following:

   - javadoc.zip. This is the Wingfoot SOAP API as a Javadoc.  It can be
     extracted in any suitable location.

   - WSOAP_User_Guide1_03.pdf.  A small document that provides an overview of 
     Wingfoot SOAP.

   - interop.html.  Results of the interop test conducted on Wingfoot SOAP.

3. A directory named wsoap/lib.  This has the necessary jarfiles that can be
   used to access Wingfoot SOAP API.

   - j2sewsoap_1.03.jar: This jar file targets the J2SE and J2EE platform. 
     It can be used in CDC/Personal Java platforms. It includes an XML parser.

   - kvmwsoap_1.03.jar: This jar file targets the J2ME (CLDC/MIDP) 
     platform. It is preverified and includes an XML parser.


Please direct any questions to info@wingfoot.com . Information about Wingfoot
Software Inc. and the products offered are available at http://www.wingfoot.com.

