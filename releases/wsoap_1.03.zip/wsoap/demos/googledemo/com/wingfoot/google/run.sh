java -classpath /home/ksiyer/wingfoot_development/soap/build/lib/j2sewsoap_1.03.jar:/home/baldwinl/devel/wingfoot_development/soap/demos/googledemo:. com.wingfoot.google.Google $1
